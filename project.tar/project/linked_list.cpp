#include <stdlib.h>
#include <stdio.h>

class Node
{
private:
	int value;
	Node* prev;
	Node* next;

public:
        int	temp;
        void set_value(int x){ value = x;}
        int  get_value(void){return value;}
        void set_prev(Node* n){prev=n;}
	void set_next(Node* n){next=n;}
	Node* get_prev(void){return prev;}
	Node* get_next(void){return next;}
	long long get_addr(void){return (long long)&value;}


};



class List
{
private:
Node* head;
Node* tail;
int num;
public:
List(void) { head = (Node *)malloc(sizeof(Node));  tail=head;num=0;	}

void append(Node n){
		
		n.set_prev(tail);
		tail->set_next(&n);
		tail=&n;
		
		}


Node* get_head(void){return head;}
Node* get_tail(void){return tail;}


};


void my_malloc(Node* n[], int i) { n[i] = (Node *)malloc(sizeof(Node)*2);
			// printf("%lx\t%d\n",(long long)n[i],sizeof(Node)*2);
			 
			return ;}


int main(void){

List sumin;
Node* nodes[10000];
for(int i=0; i<10000; i++) {   my_malloc(nodes, i);    }
for(int i=0; i<10000; i++) {		sumin.append(nodes[i][0]);}
nodes[0][0].set_value(35);
nodes[0][0].temp=0;
for(int j=0; j<1000; j++)
for(int i=0; i<10000; i++) nodes[i+1][0].temp = nodes[i][0].temp+3;//nodes[i+1].set_value(nodes[i].get_value()+3);



for (int k=0; k<10; k++)
for(int j=0; j<1000; j++)
for(int i=0; i<9900; i++) nodes[i+1][0].temp = nodes[i][0].temp+3;//nodes[i+1].set_value(nodes[i].get_value()+3);
FILE *fp = fopen("Real_leak.txt","w");
for (int i=9900 ; i<10000;i++) fprintf(fp, "Leak : %lx\n",&nodes[i][0]);


 return 0;}
