#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
double ohno;
uint64_t stack[2];
uint64_t heap[2];
int id=0;
int ip=0;
int pt=0;
int ts=0;
int periods=0;
int datas=0;
int registers=0;
int abc=0;
int weight=0;
uint64_t addrs=0;

perf_record_exit(FILE *fp,FILE *event_pointer){
int i;
uint32_t eattr_size;
unsigned char sattr[8];
printf("\npid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);

printf("\ntid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);

printf("\ntid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


printf("\ntid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);






unsigned char auta[8];
uint64_t addr;
printf("time stamp : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&auta[i]);sattr[i]=auta[i]; }
for(i=0; i<8; i++) {printf("%02x",auta[7-i]); 	}
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
FILE *fin = fopen("exit_time.txt","w");
fprintf(fin,"%lx\n",addr);

}


void perf_record_sample(FILE *fp, FILE *event_pointer, FILE *stalenessa){

abc++;
unsigned char sattr[8];
int i;
uint32_t eattr_size;

uint64_t addr;
if(ip==1){
printf("instruction pointer : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<4; i++) {printf("%02x",sattr[3-i]);  		}
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

}
if(pt==1){
printf("\npid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


printf("tid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);
}
unsigned char auta[8];
unsigned char aut[8];
uint64_t tempt;
if (ts==1){
printf("time stamp : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&auta[i]);sattr[i]=auta[i]; }
for(i=0; i<8; i++) {printf("%02x",auta[7-i]); 	}
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
tempt =  sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
}
unsigned long long tempa;

if(addrs==1){
printf("\naddrs : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&aut[i]); sattr[i]=aut[i]; }
for(i=0; i<8; i++) {printf("%02x",aut[7-i]);  	}
tempa= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24)
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40)
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

if(tempa>heap[0] && tempa<heap[1]) for(i=0; i<8; i++)fprintf(stalenessa,"%02x",auta[7-i]);
//printf("\ntempa : %016lx\n",tempa);
if(tempa>heap[0] && tempa<heap[1]) { fprintf(stalenessa,"\t%016lx\t", tempa);	}
} 

if(id==1){
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("\nid : %08x\n",(int)addr);
}

if(periods==1){
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("\nperiod : %08x\n",(int)addr);
} 

if(weight==1){

for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24)
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40)
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("\nweight : %08x\n",(int)addr);
}




if(datas==1){
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("\ndata src : %08x\n",addr);
} 

if( (addr & 1) ) printf("--Perf mem not available!\n");
if( (addr & (1<<1)) ) { if(tempa>heap[0] && tempa<heap[1])fprintf(stalenessa, "Load\n");printf("--Load instruction\n"); }
if( (addr & (1<<2)) ) { if(tempa>heap[0] && tempa<heap[1])fprintf(stalenessa, "Store\n");printf("--Store instruction\n");}
if( (addr & (1<<3)) ) printf("--Prefetch instruction\n");
if( (addr & (1<<4)) ) printf("--Execution instruction\n");

if(registers==1){
printf("\n\nRegisters\n");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

if(addr==2) printf("This is PERF_SAMPLE_REGS_ABI_64\n",addr);



for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RAX : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RBX : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RCX : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RDX : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RSI : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RDI : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RBP : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RSP : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("RIP : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("flags : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("CS : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("SS : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R8 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R9 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R10 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R11 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R12 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R13 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R14 : %08x\n",addr);
 
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
 addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf("R15 : %08x\n",addr);
 




  		}

printf("\n\n\n");



return;}

unsigned char exact[8];

void perf_record_mmap2(FILE *fp, FILE *event_pointer){
unsigned char sattr[8];
unsigned char michin[8];
int i;
uint32_t eattr_size;
printf("pid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


printf("tid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);

uint64_t stacka;
uint64_t addr;
double oo;
printf("addr : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%02x",sattr[7-i]); michin[i]=sattr[7-i];	}
stacka= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
oo = sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24)
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40)
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
uint64_t len;
printf("\nlen : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
len= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);


printf("\npage offset : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\nmajor ID : ");
for(i=0; i<4; i++) {fscanf(fp,"%c",&sattr[i]); }
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);

printf("minor ID : ");
for(i=0; i<4; i++) {fscanf(fp,"%c",&sattr[i]); }
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);



printf("inode number : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",addr);


printf("inode generation : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",addr);

for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }


printf("\nfile name : ");
char fname[100];
int  ind=0;
while(ftell(event_pointer)>ftell(fp)) {fscanf(fp,"%c",&sattr[i]); printf("%c",sattr[i]); fname[ind++]=sattr[i];}
printf("\n\n\n");

if(fname[1] == 's' && fname[2] == 't' && fname[3] == 'a' && fname[4] == 'c' && fname[5] =='k' && fname[6]==']') {for(i=0;i<8;i++)exact[i]=michin[i];ohno=oo; stack[0] = stacka; stack[1] = stacka+len; }
if(fname[1] == 'h' && fname[2] == 'e' && fname[3] == 'a' && fname[4] == 'p' && fname[5] ==']') { heap[0] = stacka; heap[1] = stacka+len; }

return;}



void perf_record_mmap(FILE *fp, FILE *event_pointer){
unsigned char sattr[8];
int i;
uint32_t eattr_size;
printf("pid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


printf("tid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


uint64_t addr;
printf("addr : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\nlen : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\npage offset : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\nfile name : ");
while(ftell(event_pointer)>ftell(fp)) {fscanf(fp,"%c",&sattr[i]); printf("%c",sattr[i]); }
printf("\n\n\n");

return;}


void perf_record_comm(FILE *fp, FILE *event_pointer){
unsigned char sattr[8];
int i;
uint32_t eattr_size;
printf("pid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


printf("tid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


while(ftell(event_pointer)>ftell(fp)) {fscanf(fp,"%c",&sattr[i]); if(sattr[i]!=0)printf("%c",sattr[i]); }

printf("\n\n\n");
return ;}

//void perf_record_

void perf_record(FILE *fp, FILE *event_pointer, FILE *stalenessa){
int i;
unsigned char sattr[8];
uint32_t data_type;
printf("data_type : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
data_type= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"",data_type);
if(data_type==1) printf(", MMAP event\n");
if(data_type==3) printf(", Change process\n");
if(data_type==10)printf(", MMAP2 event\n");
if(data_type==9) printf(", sample record\n");
if(data_type==4) printf(", EXIT event\m");
uint16_t data_misc;
for(i=0; i<2; i++) fscanf(fp,"%c", &sattr[i]);
data_misc= sattr[0] | (sattr[1]<<8);
printf("data_misc : %"PRIu16", sample happend in Kernel\n",data_misc);


uint16_t datasize;
for(i=0; i<2; i++) fscanf(fp,"%c", &sattr[i]);
datasize = sattr[0] | (sattr[1]<<8);
printf(" data_size : %"PRIu16"\n",datasize);


fseek( event_pointer, datasize, SEEK_CUR );
if(data_type==1) perf_record_mmap(fp,event_pointer);
else if(data_type==3) perf_record_comm(fp,event_pointer);
else if(data_type==10) perf_record_mmap2(fp,event_pointer);
else if(data_type==9) perf_record_sample(fp,event_pointer,stalenessa);
else if(data_type==4) perf_record_exit(fp,event_pointer);
else {
while(ftell(event_pointer)>ftell(fp)) fscanf(fp,"%c",&sattr[i]);
printf("\n\n\n");}

while(ftell(event_pointer)>ftell(fp)) fscanf(fp,"%c",&sattr[i]);

return;}





/**************

main




**********
***********/

int main(void){
int i;
FILE *fp;
unsigned char sattr[8];

fp = fopen("perf.data", "r");
char temp;

printf("MAGIC : ");
for(i=0; i<8; i++){
fscanf(fp,"%c",&temp);
printf("%c",temp);
}
printf("\n");

uint64_t hsize;
printf("size of header : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
hsize= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",hsize);

/**********/


uint64_t size_attr;
printf("size of attr : ");
for(i=0; i<8; i++){
fscanf(fp,"%c",&sattr[i]);
}
size_attr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",size_attr);


/*************/
uint64_t attr_offset;
printf("section attr_offset : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_offset= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",attr_offset);

uint64_t attr_size;
printf("section attr_size : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",attr_size);


uint64_t data_offset;
printf("section data_offset : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
data_offset= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",data_offset);



uint64_t data_size;
printf("section data_size : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
data_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",data_size);


FILE *data_pointer=fopen("perf.data","r");;
 fseek(data_pointer, data_offset+data_size, SEEK_SET);


uint64_t event_offset;
printf("section event_offset : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
event_offset= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",event_offset);

uint64_t event_size;
printf("section event_size : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
event_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n\n",event_size);


for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);

fseek( fp, attr_offset, SEEK_SET );


uint32_t attr_type;
printf("attr_type : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
attr_type= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32", hardware event\n",attr_type);

uint32_t eattr_size;
printf("attr_size : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);

uint64_t attr_config;
printf("attr_config : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_config= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",attr_config);

uint64_t attr_period;
printf("attr_period :");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_period= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",attr_period);

/*
printf("attr_frequency :");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_period= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",attr_period);
*/




uint64_t attr_sample_type;
printf("attr_sampe_type :\n");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_sample_type= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("The number : %d\n\n",attr_sample_type);
if(attr_sample_type & 1) {printf("--Instruction Pointer\n"); ip = 1;}
if(attr_sample_type & (1<<1) ) {printf("--PID and TID\n"); pt=1; }
if(attr_sample_type & (1<<2) ) {printf("--Timestamp\n"); ts = 1;}
if(attr_sample_type & (1<<3) ) {printf("--Address\n"); addrs=1;}
if(attr_sample_type & (1<<6) ) {printf("--Id\n"); id = 1;}
if(attr_sample_type & (1<<8) ) {printf("--period\n"); periods=1;}
if(attr_sample_type & (1<<14)) {printf("--weight\n"); weight=1;}
if(attr_sample_type & (1<<15)) {printf("--data src\n"); datas=1;}

if(attr_sample_type & (1<<18)) {printf("--Int Registers\n"); registers=1;}

//printf(" %"PRIu64", CPU number included\n",attr_sample_type);

uint64_t attr_read_format;
printf("attr_read_format :");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_read_format= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",attr_read_format);

/*long part~*/
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
attr_read_format= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);


printf("--disabled : %d \"off by default\"\n",(int)attr_read_format & 1);
printf("--inherit : %d \"children inherit it\"\n",((int)attr_read_format & 2)>>1 );
printf("--pinned : %d \"must always be on PMU\"\n",(int)attr_read_format & 4);
printf("--exclusive : %d \"only group on PMU\"\n",(int)attr_read_format & 8);
printf("--exclude_user : %d \"don't count user\"\n",(int)attr_read_format & 16);
printf("--exclude_kernel : %d \"ditto kernel\"\n",(int)attr_read_format & 32);
printf("--exclude_hv : %d \"exclude_hv\"\n",(int)attr_read_format & 64);
printf("--exclude_idle : %d \"don't count when idle\"\n",(int)attr_read_format & 128);
printf("--mmap : %d \"mmap recordes are included\"\n",((int)attr_read_format & 256) >> 8);
printf("--comm : %d \"comm recordes are included\"\n",((int)attr_read_format & 512) >> 9);
printf("--freq : %d \"sample_freq is valid\"\n",((int)attr_read_format & 1024)>>10);
printf("--inherit_stat : %d \"per task counts\"\n",(int)attr_read_format & 1024*2);
printf("--enable_on_exec : %d \"next exec enables\"\n",((int)attr_read_format & 1024*4)>>12);
printf("--task : %d \"trace fork/exit\"\n",((int)attr_read_format & 1024*8) >> 13);
printf("--watermark : %d \"wakeup_watermark\"\n",(int)attr_read_format & 1024*16);
printf("--precise_ip : %d \"0~3\"\n",(int)attr_read_format & 1024*32+1024*64);
printf("--mmap_data : %d \"non-exec mmap data\"\n",(int)attr_read_format & 1024*128);
printf("--sample_id_all : %d \"sample_id\"\n",((int)attr_read_format & 1024*256)>> 18);
printf("--exclude_host : %d \"don't count in host\"\n",((int)attr_read_format & 1024*512)>> 19);
printf("--exclude_guest : %d \"don't count in guest\"\n",((int)attr_read_format & 1024*1024)>> 20);
printf("--exclude_callchain_kernel : %d \"exclude kernel cllchain\"\n",((int)attr_read_format & 1024*1024*2)>> 21);
printf("--exclude_callchain_user : %d \"exclude user callchain\"\n",((int)attr_read_format & 1024*1024*4)>> 22);
printf("--mmap2 : %d \"include mmap with inode data\"\n",((int)attr_read_format & 1024*1024*8)>> 23);
printf("--comm-exec : %d \"flag comm events that due to exec\"\n",((int)attr_read_format & 1024*1024*16)>> 24);
printf("--use_clockid : %d \"use clockid for timefield\"\n",((int)attr_read_format & 1024*1024*32)>> 25);
/*int r=1024*1024*32;
for(i=0; i<38; i++) {
r*=2;
printf("--TEST : %d \"reserved\"\n",(int)attr_read_format & 1024*r);
		}
*/
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);



uint64_t ids_offset;
printf("section ids_offset : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
ids_offset= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n",ids_offset);

uint64_t ids_size;
printf("section ids_size : ");
for(i=0; i<8; i++) fscanf(fp,"%c",&sattr[i]);
ids_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);
printf(" %"PRIu64"\n\n",ids_size);



FILE *event_pointer; event_pointer = fopen("perf.data", "r");
fseek( event_pointer, data_offset, SEEK_SET );
uint32_t data_type;

//printf("fffffffffffffffff : 	%d, %d\n", ftell(fp), ftell(event_pointer));

printf("data_type : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
data_type= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32", MMAP event\n",data_type);

uint16_t data_misc;
for(i=0; i<2; i++) fscanf(fp,"%c", &sattr[i]);
data_misc= sattr[0] | (sattr[1]<<8);
printf("data_misc : %"PRIu16", sample happend in Kernel\n",data_misc);

uint16_t datasize;
for(i=0; i<2; i++) fscanf(fp,"%c", &sattr[i]);
datasize = sattr[0] | (sattr[1]<<8);
//printf(" data_size : %"PRIu16"\n",datasize);


fseek( event_pointer, datasize, SEEK_CUR );
if(data_type==1){
printf("pid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


printf("tid : ");
for(i=0; i<4; i++) fscanf(fp,"%c",&sattr[i]);
eattr_size= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24);
printf(" %"PRIu32"\n",eattr_size);


uint64_t addr;
printf("addr : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\nlen : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\npage offset : ");
for(i=0; i<8; i++) {fscanf(fp,"%c",&sattr[i]); }
for(i=0; i<8; i++) {printf("%x",sattr[7-i]); }
addr= sattr[0] | (sattr[1]<<8) | (sattr[2]<<16) |(sattr[3]<<24) 
|((uint64_t)sattr[4]<<32) |((uint64_t)sattr[5]<<40) 
|((uint64_t)sattr[6]<<48) |((uint64_t)sattr[7]<<56);

printf("\nfile name : ");
while(ftell(event_pointer)>ftell(fp)) {fscanf(fp,"%c",&sattr[i]); printf("%c",sattr[i]); }
printf("\n\n\n");
}
static FILE *stalenessa;
 stalenessa = fopen("staleness.txt","w");

while(ftell(data_pointer)>ftell(fp))
perf_record(fp,event_pointer,stalenessa);


printf("Total Number of Sample : %d\n",abc);
for( i=0; i<8; i++){
printf("%02x",exact[i]); }
printf("\n%016x",(uint64_t)ohno);
printf("\n");
printf("Stack Area : %016lx to %016lx,  the length is %016lx\n", stack[0], stack[1], stack[1]-stack[0]);
printf("Heap Area  : %016lx to %016lx,  the length is %016lx\n", heap[0], heap[1], heap[1]-heap[0]);

return 0;}

