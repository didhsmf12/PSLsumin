#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int compare (void *first, void *second)
{
    if (*(int*)first > *(int*)second)
        return 1;
    else if (*(int*)first < *(int*)second)
        return -1;
    else 
        return 0;
}

int dcompare (void *first, void *second)
{
    if (*(double*)first > *(double*)second)
        return 1;
    else if (*(double*)first < *(double*)second)
        return -1;
    else 
        return 0;
}

int main(void){
	int j,i;
	FILE *fp = fopen("dead_leak.txt","r");
	int number = 1000000;
	int  *staleness = (int *)malloc(sizeof(int)*1000000);
	for(i=0; i<1000000;i++) staleness[i]=0;
	i=0;
	int ending;
       // printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	for(i=0; i<1000000;i++){
		ending=fscanf(fp,"%d",&staleness[i]);
		if (ending==EOF) break;
		//printf("%d\n",i);
			}

	int starting;
	ending = 0;
        double median_v;
	int median;
	double h;
 	double *MC = (double * ) malloc(sizeof(double)*100000000.0);
      	for(i=0; i<100000000; i++) MC[i]=0;
	qsort(staleness,1000000,sizeof(int),compare);
	for(i=0; i<1000000;i++){if(staleness[i]!=0){

				if(ending==0) {ending=1;starting = i; }
				}
			 }
//	printf("starting: %d\n",starting);	
	
	median = (starting+999999)/2;
	median_v = staleness[median];
	printf("median : %lf, %d\n",median_v, median); 
	int k=0;
	for(i=starting; i<=median; i++)
	{
		for(j=median; j<1000000; j++)
		{ if(k==99999999) printf("!!!!\n");
		if(i!=j)MC[k++] = ((double)staleness[j] - median_v  - median_v + (double)staleness[i])/((double)staleness[j]-(double)staleness[i])	;
	//	printf("%d\n",k);
			}	
	}
	printf("!!!!\n");
	qsort(MC, k, sizeof(double), dcompare);
        double MC_med = MC[k/2];
	printf("MC : %lf\n",MC_med);
//	for(i=0; i<10000; i++)		printf("%d,   %lf\n",i,MC[i]);
	double threshold;
	if(MC>=0) {threshold = staleness[(median+999999)/2]+3.0*exp(3*MC_med); }

	printf("Threshold : %lf\n",threshold);
	for(i=0; i<1000000; i++) if(staleness[i]>threshold){ printf("%d,  %lf\n",i,staleness[i]); break;}

	int interval = 10000000;
	int *data = (int *)malloc(sizeof(int)*1000000);
		for(i=0; i<1000000;i++)  data[i]=0;
		for(i=0; i<1000000;i++)  data[staleness[i]/interval]++;
	FILE *re = fopen("sampling_results.txt","w");
	for(i=1; i<1000000;i++) if(data[i]>0)fprintf(re,"%d\t%ld\n",i,data[i]);
	




return 0;}
