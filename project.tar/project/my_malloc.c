#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
static void* (*real_malloc)(size_t)=NULL;

static void mtrace_init(void)
{
    real_malloc = dlsym(RTLD_NEXT, "malloc");
    if (NULL == real_malloc) {
        fprintf(stderr, "Error in `dlsym`: %s\n", dlerror());
    }
}

void *malloc(size_t size)
{
    if(real_malloc==NULL) {
        mtrace_init();
    }

    void *p = NULL;
    p = real_malloc(size); 


    fprintf(stderr, "%016lx\t%d\n", p,size);
    return p;
}
