#include <stdio.h>
#include <string.h>



int main(void){
char* store[6];
long long addr[10000];
int size;
FILE *stalness = fopen("dead_leak.txt","w");
int staleness;
int  checker[10000];
int i;
FILE *fp;
fp = fopen("malloc_trace.txt","r");
int cur;
int endi=0;


/*move malloc data into memory.*/

for(i=0; i<10000;i++) {checker[i]=0;  endi=fscanf(fp,"%lx%d",&addr[i],&size);  
			i++;
		  cur = ftell(fp);
		  char a;
		  fscanf(fp, "%c",&a);
		  if(a=='[') break;
		  else fseek(fp,cur,SEEK_SET);

			 }
unsigned long long stamp[10000];
long long time;
long long access;
int ending;
FILE *fx;
fx = fopen("staleness.txt","r");
while(ending!=EOF){

		ending=fscanf(fx,"%lx%lx%s",&time,&access,store);
		for(i=0; i<10000; i++){	 if(access>addr[i] && access<addr[i]+size) {
						if(checker[i]==0){	checker[i]=1;	stamp[i]=time;}		
						else {  //printf("%lx have staleness %lx\n",addr[i],time-stamp[i]);
							staleness = time-stamp[i];
							//fprintf(stalness,"%d\n",staleness);
							stamp[i]=time;
									}
										}
		
				}
		//printf("timestamp:%lx\n",time);
		}


/*now compute stalness with exit time*/
FILE *fin = fopen("exit_time.txt","r");
long long fin_time;
fscanf(fin,"%lx",&fin_time);

for(i=0; i<10000; i++){ 

if(checker[i]==1){ staleness = fin_time - stamp[i];
fprintf(stalness,"%d\n",staleness);
}


		}






//for(i=0; i<10000; i++) if(checker[i]==0) printf("%lx is not used! (leak)\n",addr[i]);
FILE *unaccess = fopen("nouse_leak.txt","w");
for(i=0; i<10000; i++) if(checker[i]==0) fprintf(unaccess,"%lx is not used! (leak)\n",addr[i]);
 
return 0;}
